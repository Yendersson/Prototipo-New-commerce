export default {
    STR_CNX: 'mongodb+srv://newcommerce:puma@cluster0.gnl9obi.mongodb.net/?retryWrites=true&w=majority'
}